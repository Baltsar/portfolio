Läs dessa filer i mappen som referens:
- CLAUDE-CODE-BRIEF.md (designsystem, tokens, regler)
- visual-spec.html (visuell sanning)
- final-preview.html (open-knapp med spinner, rich text components)
- glyph-spinner-preview.html (list-glyph-animation med idle nudge)
- hero-final.html (ny hero-design)
- content-pack.md (projektinnehåll och data)
- PROJEKT-TEMPLATE-GUIDE.md (template-struktur)

Gör ALLA ändringar nedan. Testa visuellt efter varje steg. Börja med 1-4 (snabbast), sedan 5-7, sedan 8-10.

---

## 1. HERO — ny design

Byt HELA hero-sektionen mot designen i hero-final.html:

Stor rubrik:
```
10 years of design.
Then AI happened.
```
- font-family: var(--font-display), font-weight: 700
- font-size: clamp(2.5rem, 7vw, 5.5rem), letter-spacing: -0.05em
- "AI happened" i var(--green) med text-shadow glow
- line-height: 1

Under rubriken, en terminal-rad:
```
gustaf@garnow:~$ creative technologist · AI-native · stockholm█
```
- font-size: 0.8125rem, color: var(--text-secondary)
- Prompten i grön med glow, blinkande cursor
- Fadas in med 0.6s delay

Under terminal-raden, namn:
```
GUSTAF  BALTSAR  GARNOW
```
- GUSTAF: font-display, 0.875rem, var(--text-primary)
- BALTSAR: 0.5rem, letter-spacing 0.3em, var(--text-dim)
- GARNOW: font-display, 0.875rem, var(--green) med glow
- Fadas in med 1.2s delay

Ta bort allt annat som fanns i hero:n (den stora GUSTAF/GARNOW-texten, hero-prompt, hero-sub).

## 2. OPEN-KNAPP — alltid snurrande

Byt ut Open-knappen mot versionen i final-preview.html:
- Glyphen spinner ALLTID. Slow loop (250ms/frame) idle, fast (50ms) hover
- Varje knapp startar med random delay så de inte synkar
- Layout i project-bar: [tags] [open-btn med border-left] [drag-handle 28px]
- Spinner-sets: braille (Monero), arrows (OpenSverige), blocks (Hermes), classic (Enterprise)
- Resting glyph: den ska ALDRIG vila, den loopar hela tiden

## 3. TA BORT PILAR

Radera ALLT relaterat till flow arrows. All HTML, CSS, JS. Helt borta. Vi bygger dem rätt i v2.

## 4. TITLEBAR — grip istället för trafikljus

ALLA projektfönster: byt röd/gul/grön → grip (3 horisontella linjer, 18px, var(--win-border-dark), opacity 0.4, cursor grab).
UNDANTAG: Case study popup behåller EN röd close-cirkel (14px) + klickbar för att stänga.

## 5. CASE STUDY POPUP — fixar

### Titlebar
- EN röd close-knapp (cirkel, 14px) vänster
- Titel centrerad
- Klick utanför popup:en stänger den också
- Mobil: close-knappen MÅSTE vara tydlig och sticky

### Resize-möjlighet
- Gör case study fönstret resizable i bredd — användaren kan dra i höger kant för att göra det smalare/bredare
- CSS: resize: horizontal; overflow: auto; ELLER bygg en custom drag-handle på höger kant
- Min-width: 500px, max-width: 95vw
- Mobilvy: alltid fullbredd, ingen resize

### Implementera ALLA rich text features från final-preview.html:

**Tooltips:**
```html
<span class="term tech">MCP<span class="tip">Förklaring här.</span></span>
```
Tre varianter: .term (default), .term.tech (grön), .term.ref (blå). Hover = visa. Mobil = tap.

**Highlights:** `<span class="hl">text</span>` (grön) och `<span class="hl blue">text</span>`

**Code inline:** `<span class="code">JSON-RPC</span>`

**Pull quotes:**
```html
<div class="case-quote">"Citatet."<span class="quote-attr">— Gustaf</span></div>
```

**Stats:**
```html
<div class="case-stat"><div class="stat-number green">1st</div><div class="stat-label">I världen</div></div>
```

**Image refs:** ⊞ filnamn.png — hover triggar preview-swap i split-view

## 6. ANIMERADE LIST-GLYPHS

Implementera EXAKT som i glyph-spinner-preview.html:
- Varje li har en `<span class="glyph">` som spinner vid hover (60ms/frame, 10-16 cykler → land på resting)
- Idle nudge: var 2-6s twitchar en random glyph spontant. Två oberoende kedjor.
- Staggered entrance animation vid scroll-reveal
- Spinner-sets: braille/terminal > (Monero), arrows → (OpenSverige), blocks/bracket ] (Hermes), classic/check ✓ (Enterprise)
- MOBIL: tap istället för hover. Idle nudges kör.

## 7. PROJEKTINNEHÅLL

Använd content-pack.md och PROJEKT-TEMPLATE-GUIDE.md. Gör data-driven:
- All data i src/data/projects.json (se content-pack.md för ifyllda projekt)
- renderProject() genererar HTML från JSON
- Case study sections renderas baserat på type: intro, text, list, quote, stats
- Implementera ALLA fyra projekt med fullständigt case study-innehåll
- Alla section-typer ska vara testbara — jag vill se bullets, quotes, stats, tooltips

## 8. EXPORT

.md och .txt genererar och laddar ner riktig fil via Blob + download. Innehåll finns i content-pack.md. PDF behåller joke-response.

## 9. MOBILVY

- Projekt först, profil SIST (CSS order)
- Overlay-titel: clamp(3rem, 18vw, 5rem)
- Case study: fullbredd, stackad split-view
- Close-knapp sticky och tydlig
- Tooltips: tap
- Open-spinner: kör alltid
- Layout toggle + drag handles: göm
- Testa 375px och 390px

## 10. DRAG PERFORMANCE

- `.dragging` klass disablar transitions: `transition: none !important`
- Använd transform: translate(x,y) inte top/left
- requestAnimationFrame för DOM-batching

---

Gör allt. Steg 1-4 först, sedan 5-7, sedan 8-10.
